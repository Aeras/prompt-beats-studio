# PromptBeats Atlas V4 — Βήμα 3: Χάρτης Advanced Generator

## Πεδίο εφαρμογής

Ελέγχθηκε το πραγματικό `advanced-generator-setup.ts` (Zod strict export/import) και το `song-blueprint.shared.ts`, καθώς και οι κανόνες του AGENTS.md / WORK-STATUS.md. Πρόκειται για σχεδιασμό αντιστοίχισης, όχι runtime implementation.

## Κατανομή
- `manual_import_candidate_unverified`: **107**
- `field:additionalInstructions`: **67**
- `hold_example_required`: **3**
- `field:None`: **16**
- `field:customInstruments`: **20**
- `field:productionStyle`: **20**
- `context_only_no_injection`: **12**
- `hold_pilot_redesign`: **1**

## Σημαντικοί περιορισμοί

- Οι εντολές μπαίνουν μόνο κατόπιν ρητής επιλογής. Προτείνεται προσθήκη στο υπάρχον κείμενο, όχι αντικατάσταση.
- Οι ρυθμίσεις BPM/γλώσσας/δομής/Blueprint/ρίμας και επιλογές χρήστη έχουν πάντα προτεραιότητα.
- Τα πεδία `additionalInstructions`, `productionStyle`, `customInstruments`, `customMusicStyle` είναι πραγματικά μέλη του strict schema. **Αυτό δεν αποδεικνύει** ότι υπάρχει κώδικας για έλεγχο / εφαρμογή Atlas.
- Δεν αποδόθηκε αυθαίρετα section Blueprint: απαιτείται επιβεβαίωση exact target `structureIndex` και στοχευμένη λειτουργία.
- Η τεχνική της πρώτης ρωσικής A/B δοκιμής παραμένει inconclusive, όχι εγκεκριμένη.
- Δεν έχει γίνει ανεξάρτητη verification πηγών ή paid/in-app generation.

## Ακριβείς χειροκίνητες απαιτήσεις πριν από ενεργοποίηση

Πριν από production implementation χρειάζεται ανάγνωση end-to-end ροής advanced generator (client/import, normalization, endpoint, prompt builder, server entitlement/admission, output validation), έλεγχος parser limits, safe preview/undo, opt-in and collision handling, CI tests. Δεν έγινε στο παρόν βήμα.

## Ατομικός πίνακας

| Technique ID | Αξιολόγηση | Προτεινόμενο πεδίο | Διάσταση |
|---|---|---|---|
| `ru.protyazhnaya.option.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `lyrics` |
| `ru.protyazhnaya.option.2` | `manual_import_candidate_unverified` | `additionalInstructions` | `vocals` |
| `ru.protyazhnaya.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `vocals` |
| `ru.chastushka.option.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `lyrics` |
| `ru.chastushka.option.2` | `manual_import_candidate_unverified` | `additionalInstructions` | `vocals` |
| `ru.chastushka.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `lyrics` |
| `ru.khorovod.editorial.v3e1` | `manual_import_candidate_unverified` | `additionalInstructions` | `structure` |
| `ru.khorovod.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `structure` |
| `ru.wedding_folk.editorial.v3e1` | `manual_import_candidate_unverified` | `additionalInstructions` | `lyrics` |
| `ru.wedding_folk.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `vocals` |
| `ru.calendar_folk.editorial.v3e1` | `manual_import_candidate_unverified` | `additionalInstructions` | `lyrics` |
| `ru.calendar_folk.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `lyrics` |
| `ru.bylina.editorial.v3e1` | `manual_import_candidate_unverified` | `additionalInstructions` | `structure` |
| `ru.bylina.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `structure` |
| `ru.lyrical_folk.editorial.v3e1` | `manual_import_candidate_unverified` | `additionalInstructions` | `lyrics` |
| `ru.lyrical_folk.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `lyrics` |
| `ru.cossack_song.editorial.v3e1` | `hold_example_required` | `—` | `vocals` |
| `ru.cossack_song.v4.alternative.1` | `hold_example_required` | `—` | `vocals` |
| `ru.folk_rock.editorial.v3e1` | `manual_import_candidate_unverified` | `additionalInstructions` | `instrumentation` |
| `ru.folk_rock.v4.alternative.1` | `manual_import_candidate_unverified` | `customInstruments` | `instrumentation` |
| `ru.urban_romance.editorial.v3e1` | `manual_import_candidate_unverified` | `additionalInstructions` | `vocals` |
| `ru.urban_romance.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `vocals` |
| `ru.classical_romance.editorial.v3e1` | `manual_import_candidate_unverified` | `additionalInstructions` | `vocals` |
| `ru.classical_romance.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `vocals` |
| `ru.cruel_romance.editorial.v3e1` | `manual_import_candidate_unverified` | `additionalInstructions` | `lyrics` |
| `ru.cruel_romance.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `lyrics` |
| `ru.bard_song.option.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `lyrics` |
| `ru.bard_song.option.2` | `manual_import_candidate_unverified` | `customInstruments` | `instrumentation` |
| `ru.bard_song.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `lyrics` |
| `ru.satirical_bard.editorial.v3e1` | `manual_import_candidate_unverified` | `additionalInstructions` | `lyrics` |
| `ru.satirical_bard.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `lyrics` |
| `ru.hiking_song.editorial.v3e1` | `manual_import_candidate_unverified` | `additionalInstructions` | `structure` |
| `ru.hiking_song.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `vocals` |
| `ru.blatnaya.option.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `lyrics` |
| `ru.blatnaya.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `lyrics` |
| `ru.lager_song.editorial.v3e1` | `manual_import_candidate_unverified` | `additionalInstructions` | `lyrics` |
| `ru.lager_song.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `vocals` |
| `ru.odessa_song.editorial.v3e1` | `manual_import_candidate_unverified` | `additionalInstructions` | `lyrics` |
| `ru.odessa_song.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `lyrics` |
| `ru.emigre_song.editorial.v3e1` | `manual_import_candidate_unverified` | `additionalInstructions` | `lyrics` |
| `ru.emigre_song.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `lyrics` |
| `ru.lyrical_chanson.editorial.v3e1` | `manual_import_candidate_unverified` | `additionalInstructions` | `vocals` |
| `ru.lyrical_chanson.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `lyrics` |
| `ru.post_chanson.editorial.v3e1` | `manual_import_candidate_unverified` | `productionStyle` | `production` |
| `ru.post_chanson.v4.alternative.1` | `manual_import_candidate_unverified` | `productionStyle` | `production` |
| `ru.soviet_estrada_50_60.editorial.note` | `context_only_no_injection` | `—` | `era` |
| `ru.soviet_estrada_50_60.v4.alternative.1` | `manual_import_candidate_unverified` | `customInstruments` | `instrumentation` |
| `ru.soviet_estrada_70.editorial.note` | `context_only_no_injection` | `—` | `instrumentation` |
| `ru.soviet_estrada_70.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `vocals` |
| `ru.soviet_estrada_80.editorial.note` | `context_only_no_injection` | `—` | `era` |
| `ru.soviet_estrada_80.v4.alternative.1` | `manual_import_candidate_unverified` | `customInstruments` | `instrumentation` |
| `ru.via.editorial.note` | `context_only_no_injection` | `—` | `cultural_context` |
| `ru.via.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `vocals` |
| `ru.estrada_folk.editorial.v3e1` | `manual_import_candidate_unverified` | `additionalInstructions` | `instrumentation` |
| `ru.estrada_folk.v4.alternative.1` | `hold_example_required` | `—` | `instrumentation` |
| `ru.russian_pop_90.editorial.note` | `context_only_no_injection` | `—` | `era` |
| `ru.russian_pop_90.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `structure` |
| `ru.russian_dance_pop_00.editorial.note` | `context_only_no_injection` | `—` | `groove` |
| `ru.russian_dance_pop_00.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `structure` |
| `ru.russian_pop_ballad.option.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `vocals` |
| `ru.russian_pop_ballad.editorial.v3e1` | `manual_import_candidate_unverified` | `additionalInstructions` | `lyrics` |
| `ru.russian_pop_ballad.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `vocals` |
| `ru.modern_russian_pop.editorial.note` | `context_only_no_injection` | `—` | `production` |
| `ru.modern_russian_pop.v4.alternative.1` | `manual_import_candidate_unverified` | `productionStyle` | `production` |
| `ru.indie_pop.editorial.v3e1` | `manual_import_candidate_unverified` | `productionStyle` | `production` |
| `ru.indie_pop.v4.alternative.1` | `manual_import_candidate_unverified` | `customInstruments` | `instrumentation` |
| `ru.synth_pop.editorial.v3e1` | `manual_import_candidate_unverified` | `customInstruments` | `instrumentation` |
| `ru.synth_pop.v4.alternative.1` | `manual_import_candidate_unverified` | `customInstruments` | `instrumentation` |
| `ru.rock_70.editorial.note` | `context_only_no_injection` | `—` | `era` |
| `ru.rock_70.v4.alternative.1` | `manual_import_candidate_unverified` | `customInstruments` | `instrumentation` |
| `ru.russian_rock_80.editorial.note` | `context_only_no_injection` | `—` | `cultural_context` |
| `ru.russian_rock_80.v4.alternative.1` | `manual_import_candidate_unverified` | `customInstruments` | `instrumentation` |
| `ru.soviet_postpunk.option.1` | `manual_import_candidate_unverified` | `productionStyle` | `groove` |
| `ru.soviet_postpunk.option.2` | `manual_import_candidate_unverified` | `additionalInstructions` | `vocals` |
| `ru.soviet_postpunk.v4.alternative.1` | `manual_import_candidate_unverified` | `customInstruments` | `instrumentation` |
| `ru.russian_art_rock.editorial.v3e1` | `manual_import_candidate_unverified` | `additionalInstructions` | `structure` |
| `ru.russian_art_rock.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `structure` |
| `ru.social_rock.editorial.note` | `context_only_no_injection` | `—` | `lyrics` |
| `ru.social_rock.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `lyrics` |
| `ru.russian_rock_ballad.option.1` | `manual_import_candidate_unverified` | `productionStyle` | `dynamics` |
| `ru.russian_rock_ballad.editorial.v3e1` | `manual_import_candidate_unverified` | `productionStyle` | `dynamics` |
| `ru.russian_rock_ballad.v4.alternative.1` | `manual_import_candidate_unverified` | `customInstruments` | `instrumentation` |
| `ru.russian_punk.editorial.v3e1` | `manual_import_candidate_unverified` | `productionStyle` | `production` |
| `ru.russian_punk.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `structure` |
| `ru.russian_alt_rock.editorial.v3e1` | `manual_import_candidate_unverified` | `customInstruments` | `instrumentation` |
| `ru.russian_alt_rock.v4.alternative.1` | `hold_pilot_redesign` | `—` | `instrumentation` |
| `ru.russian_indie_rock.editorial.v3e1` | `manual_import_candidate_unverified` | `additionalInstructions` | `vocals` |
| `ru.russian_indie_rock.v4.alternative.1` | `manual_import_candidate_unverified` | `customInstruments` | `instrumentation` |
| `ru.shoegaze.editorial.v3e1` | `manual_import_candidate_unverified` | `productionStyle` | `production` |
| `ru.shoegaze.v4.alternative.1` | `manual_import_candidate_unverified` | `productionStyle` | `production` |
| `ru.folk_metal.editorial.v3e1` | `manual_import_candidate_unverified` | `customInstruments` | `instrumentation` |
| `ru.folk_metal.v4.alternative.1` | `manual_import_candidate_unverified` | `customInstruments` | `instrumentation` |
| `ru.rap_90.option.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `rhythm` |
| `ru.rap_90.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `rhythm` |
| `ru.rap_00.editorial.note` | `context_only_no_injection` | `—` | `rhythm` |
| `ru.rap_00.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `rhythm` |
| `ru.conscious_rap.editorial.v3e1` | `manual_import_candidate_unverified` | `additionalInstructions` | `lyrics` |
| `ru.conscious_rap.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `lyrics` |
| `ru.battle_rap.editorial.v3e1` | `manual_import_candidate_unverified` | `additionalInstructions` | `lyrics` |
| `ru.battle_rap.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `lyrics` |
| `ru.trap.editorial.v3e1` | `manual_import_candidate_unverified` | `productionStyle` | `groove` |
| `ru.trap.v4.alternative.1` | `manual_import_candidate_unverified` | `productionStyle` | `groove` |
| `ru.melodic_rap.editorial.v3e1` | `manual_import_candidate_unverified` | `additionalInstructions` | `vocals` |
| `ru.melodic_rap.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `vocals` |
| `ru.drill.editorial.v3e1` | `manual_import_candidate_unverified` | `productionStyle` | `groove` |
| `ru.drill.v4.alternative.1` | `manual_import_candidate_unverified` | `productionStyle` | `groove` |
| `ru.cloud_rap.editorial.v3e1` | `manual_import_candidate_unverified` | `productionStyle` | `production` |
| `ru.cloud_rap.v4.alternative.1` | `manual_import_candidate_unverified` | `productionStyle` | `production` |
| `ru.phonk.editorial.note` | `context_only_no_injection` | `—` | `cultural_context` |
| `ru.phonk.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `instrumentation` |
| `ru.hyperpop.option.1` | `manual_import_candidate_unverified` | `productionStyle` | `production` |
| `ru.hyperpop.editorial.v3e1` | `manual_import_candidate_unverified` | `additionalInstructions` | `vocals` |
| `ru.hyperpop.v4.alternative.1` | `manual_import_candidate_unverified` | `productionStyle` | `production` |
| `ru.russian_electropop.editorial.v3e1` | `manual_import_candidate_unverified` | `customInstruments` | `instrumentation` |
| `ru.russian_electropop.v4.alternative.1` | `manual_import_candidate_unverified` | `customInstruments` | `instrumentation` |
| `ru.downtempo.editorial.v3e1` | `manual_import_candidate_unverified` | `productionStyle` | `groove` |
| `ru.downtempo.v4.alternative.1` | `manual_import_candidate_unverified` | `productionStyle` | `groove` |
| `ru.folk_electronic.editorial.v3e1` | `manual_import_candidate_unverified` | `customInstruments` | `instrumentation` |
| `ru.folk_electronic.v4.alternative.1` | `manual_import_candidate_unverified` | `customInstruments` | `instrumentation` |
| `ru.pop_chanson.editorial.v3e1` | `manual_import_candidate_unverified` | `additionalInstructions` | `vocals` |
| `ru.pop_chanson.v4.alternative.1` | `manual_import_candidate_unverified` | `additionalInstructions` | `vocals` |
| `ru.rap_rock.editorial.v3e1` | `manual_import_candidate_unverified` | `additionalInstructions` | `vocals` |
| `ru.rap_rock.v4.alternative.1` | `manual_import_candidate_unverified` | `customInstruments` | `instrumentation` |
