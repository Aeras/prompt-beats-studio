# Codex handoff — Atlas V4 one coherent PR #450

Repository: `Aeras/prompt-beats-studio`.
Current observed main `467e0b15098969a9dbec01e3defc6fdce19b4616`; open Draft PR #450 HEAD `987e65a326df55292ef5e426236c27df096a3c10` as checked 2026-10-31. **Re-fetch current state.**

**Mandatory:** read root `AGENTS.md` in live repo first, then `docs/WORK-STATUS.md`, compare actual main/PR HEAD and all active overlapping changes. Preserve Lovable history; no force-push/rewrite. Investigate before editing. Make **one cohesive PR update** rather than separate PRs. Do not merge, publish, deploy, spend on AI calls, activate Atlas, or change production databases without explicit approval. Work on #450 only if scope and actual branch state confirm it is correct; otherwise explain conflict and safe next step.

## Available evidence artifacts from ChatGPT

- `PromptBeats_Atlas_V4_123_Techniques_Compatibility_Completion_Step4c_20261031.json` (123 original technique objects preserved, 5,671 candidate pair statuses; status explicit UNKNOWN for 5,614 previously non-semantically-reviewed pairs; 57 preliminary same-profile reviews; 16 pure offline policy assertions passing; 10 pilot case specs).
- `PromptBeats_Atlas_V4_Compatibility_Completion_Step4c_Report_20261031.md`.
- `PromptBeats_Atlas_V4_10_Offline_Pilot_AB_Setups_20261031.zip`: ten pairs of JSON setup fixtures, shape/required keys and exactly-one-setup-field delta verified; **not tested on Generator**. Do not assume genre appropriateness of generic base fixtures.
- Existing Step2/Step3/Step4b JSON attachments. Original merged 636 research file is research data, not proof of a technique-specific executable rule.

## End-to-end task

1. Audit current Atlas implementation and any existing integration points (`src/lib/advanced-generator-setup.ts`, `src/lib/song-blueprint.shared.ts`, Advanced Generator UI, server generation/prompt assembly, auth, job admission, related migrations, tests, runtime usage). Verify actual app contract before implementation.
2. Preserve immutable 123 IDs, source text, provenance, explicit editorial/classification/approval states; never mistake auto-matched research IDs, 57 preliminary pair assessments, or 16 in-memory policy checks for verified musical compatibility.
3. Provide an offline **opt-in** candidate Atlas-to-Generator path with user-visible exact preview, deterministic single-technique insertion into *correct field* (not silent overwrites), strict bounds, stable serialization; preserve language, rhyme/singability, BPM, instruments, song structure, Blueprint/energy, voice preferences, and user-provided instructions. Non-executable and context-only cannot inject. Invalid/duplicate/unknown technique must fail closed.
4. For multi-technique selection, no auto-compatibility assumption: conservative single-technique limit by default, or explicit reviewed pair rules with tests; protect against duplicate/superseded candidates and conflicting section scope. Do not mark any of 5,671 pairs as verified based only on shared field/dimension.
5. Develop **ten offline deterministic tests** for setup parsing/preview/prompt rendering, zero model/provider calls, plus negative tests (no opt-in, malformed ID, unauthorized requests, superfluous fields, overflow, conflicting user options, malformed Blueprint, ambiguity, pair mismatch) and regression for existing V5 prompt registry.
6. Run full frozen installation, TypeScript, lint, Prettier, build, offline test suite and all three required CI gates on exact final HEAD. Fix regressions in same PR. Record actual results in PR and `docs/WORK-STATUS.md`. If runtime browser/audio A/B or production release requires authorization, leave `CODE_COMPLETE_RELEASE_PENDING`, not CLOSED.
7. User's previous 2×A and 2×B Suno observations yielded no discriminating audible benefit, so do not claim perceptual quality gains. Design an informative pilot with clear predicted musical change and documented A/B control before paid runs.

**Definition of done:** One coherent, reviewed PR implementing and testing the safe agreed scope, no production activation without permission, complete provenance, reproducible offline tests, and accurately documented unresolved semantic/audio/release risks. If scope is too large or current PR #450 differs, stop risky mutations and report exact blocker; do not counterfeit completion.
